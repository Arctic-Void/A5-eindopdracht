 - Open de gehele map in Visual Studio Code.
    > Wanneer je enkel de Python map hier opent, moet je de paden aanpassen.
 - In de map Python vind je een startpunt voor het script.
 - Het Python-script schrijft de bestanden weg naar "files".